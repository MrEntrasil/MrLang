#pragma once
#include "vm.hpp"

void MrLang_initbuiltin(struct MrLangVM* vm);
